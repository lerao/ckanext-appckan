ckanext-appckan
===============

Plugin that adds a button to register the apps (CKAN) integrate with AppCKAN http://appckan.com

Installation
===============

First, install the appckan CKAN extension in your Python virtual environment. Make sure that your virtualenv is activated, then do:

<pre><code>. /usr/lib/ckan/default/bin/activate</code></pre>

<pre><code>pip install -e  git+https://github.com/lerao/ckanext-appckan.git#egg=ckanext-appckan</code></pre>

Then <code>cd</code> into the <code>ckanext-appckan</code> directory and run:

<pre><code>python setup.py develop</code></pre>

Finally, enable the extension. Edit your CKAN ini file (e.g. development.ini, production.ini), find the <code>plugins =</code> line and add the appckan plugin:

<pre><code>plugins = appckan</code></pre>

After, restart apache2 and nginx:

<pre><code>sudo service apache2 restart
sudo service nginx restart
</code></pre>

Edit the template 
===============

If you do not want to follow the steps above, you can edit your template. In linux terminal, go to the folder: 
<pre><code>cd /usr/li/ckan/default/src/ckan/ckan/templates</code></pre> 

Open <code>header.html</code>. Find the tag <code>< ul class="nav nav-pills" >...</code> and after <code>{% endblock%}</code>, insert the line in html: 

<code>< li>< a href="http://appckan.com/add-apps/?repository=<URL_API>" target="_blank">Apps< /a>< /li></code> 
