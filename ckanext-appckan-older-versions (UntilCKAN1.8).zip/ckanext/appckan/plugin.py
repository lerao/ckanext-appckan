import urllib
import genshi
import ckan.lib.helpers as h
import ckan.plugins as p
from pylons.templating import render_genshi as render_orig
import pylons
import commands

class AppCkan(p.SingletonPlugin):

    p.implements(p.IConfigurable, inherit=True)
    p.implements(p.IGenshiStreamFilter, inherit=True)
    p.implements(p.IRoutes, inherit=True)
    p.implements(p.IConfigurer, inherit=True)
    
    def configure(self, config):
	self.site_url = config.get('ckan.site_url_internally') or config.get('ckan.site_url')

    def update_config(self, config):
        pass

    def filter(self, stream):
        MENU_LINKS = """<a href="http://appckan.com/add-apps/?repository=""" + self.site_url + """ target="_blank">">Apps</a>"""
        from pylons import request
        stream = genshi.filters.Transformer('body//div[@id="mainmenu"]').append(genshi.HTML(MENU_LINKS)) | stream
        stream = genshi.filters.Transformer('//ul[contains(@class, "nav-pills")]').append(genshi.HTML(MENU_LINKS)) | stream
        return stream

