#https://github.com/okfn/ckanext-example/blob/master/setup.py
from setuptools import setup, find_packages

version = '0.2'

setup(
	name='ckanext-appckan',
	version=version,
	description="Integrate Apps with AppCKAN.com",
	long_description="""\
        When integrating your portal with AppCKAN, applications will be available through appckan.com
        address and will be described from the APP-OD (appckan.com/app-od) vocabulary.
        The community besides conferring all applications, also has the ability to take advantage of
        the API and make the desired use (appckan.com/api).
	""",
	classifiers=['Development Status :: 3 - Alpha'],  # Get strings from http://pypi.python.org/pypi?%3Aaction=list_classifiers
	keywords='Apps, CKAN, Repository Online, ',
	author='AppCKAN',
	author_email='lerao@cin.ufpe.br',
	url='http://appckan.com',
	license='bsd-3',
	packages=find_packages(exclude=['ez_setup', 'examples', 'tests']),
	namespace_packages=['ckanext', 'ckanext.appckan'],
	include_package_data=True,
	zip_safe=False,
	install_requires=[],
	entry_points=\
	"""
    [ckan.plugins]
	appckan=ckanext.appckan.plugin:AppCkan
	""",
)
